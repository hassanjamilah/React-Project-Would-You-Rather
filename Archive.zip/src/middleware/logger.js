const logger = (store) => (next) => (action) => {
    console.group(action.type)
        const result = next(action)
        console.log('action: ' , action)
        console.log('The new state is: ' , store.getState())
    console.groupEnd()
    return result
}

export default logger